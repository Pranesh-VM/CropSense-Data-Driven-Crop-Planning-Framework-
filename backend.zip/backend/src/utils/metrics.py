# Evaluation helpers
